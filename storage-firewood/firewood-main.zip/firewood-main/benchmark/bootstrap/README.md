# Bootstrap testing script

This script creates instances and sets up users for bootstrap testing. You'll need ec2 installed on your machine
and you'll need to `aws sso login` before running this script.
