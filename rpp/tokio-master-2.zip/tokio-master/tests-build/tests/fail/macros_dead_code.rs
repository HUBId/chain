#![deny(dead_code)]

use tests_build::tokio;

#[tokio::main]
async fn f() {}

fn main() {}
