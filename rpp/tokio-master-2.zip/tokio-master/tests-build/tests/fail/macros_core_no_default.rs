use tests_build::tokio;

#[tokio::main]
async fn my_fn() {}

fn main() {}
