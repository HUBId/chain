use serde_derive::Serialize;

#[derive(Serialize)]
#[serde(rename =)]
struct S;

fn main() {}
