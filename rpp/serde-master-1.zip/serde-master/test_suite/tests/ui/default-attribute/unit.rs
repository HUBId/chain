use serde_derive::Deserialize;

#[derive(Deserialize)]
#[serde(default)]
struct Unit;

fn main() {}
