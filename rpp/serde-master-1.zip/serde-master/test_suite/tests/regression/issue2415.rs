use serde_derive::Serialize;

#[derive(Serialize)]
#[serde()]
#[allow(dead_code)]
pub struct S;
