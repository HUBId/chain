//! Tool to convert Wycheproof test vectors to raw hex format
#![doc(
    html_logo_url = "https://raw.githubusercontent.com/RustCrypto/media/6ee8e381/logo.svg",
    html_favicon_url = "https://raw.githubusercontent.com/RustCrypto/media/6ee8e381/logo.svg"
)]
use std::io::Write;

// `pub mod` is used to silence "field is never read" warnings
pub mod aead;
mod aes_siv;
mod ecdsa;
mod ed25519;
mod hkdf;
pub mod mac;
mod wycheproof;

/// Test information
pub struct TestInfo {
    /// Raw data for the tests.
    pub data: Vec<Vec<u8>>,
    /// Test case description.
    pub desc: String,
}

/// Generator function which takes input parameters:
/// - contents of Wycheproof test data file
/// - algorithm name
/// - key size (in bits) to include
///   and returns the raw contents, together  with a list of test identifiers (one per entry).
type BlbGenerator = fn(&[u8], &str, u32) -> Vec<TestInfo>;

struct Algorithm {
    pub file: &'static str,
    pub generator: BlbGenerator,
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let wycheproof_dir = args
        .get(1)
        .expect("Provide directory with wycheproof vectors");
    let algorithm = args.get(2).expect("Provide algorithm family");
    let key_size = args
        .get(3)
        .expect("Provide key size in bits, or 0 for all sizes")
        .parse::<u32>()
        .expect("Key size needs to be a number of bits");
    let out_path = args.get(4).expect("Provide path for output blobby file");
    let descriptions_path = args.get(5).expect("Provide path for descriptions file");

    let algo = match algorithm.as_str() {
        "AES-GCM" => Algorithm {
            file: "aes_gcm_test.json",
            generator: aead::aes_gcm_generator,
        },
        "AES-GCM-SIV" => Algorithm {
            file: "aes_gcm_siv_test.json",
            generator: aead::aes_gcm_generator,
        },
        "CHACHA20-POLY1305" => Algorithm {
            file: "chacha20_poly1305_test.json",
            generator: aead::chacha20_poly1305,
        },
        "XCHACHA20-POLY1305" => Algorithm {
            file: "xchacha20_poly1305_test.json",
            generator: aead::xchacha20_poly1305,
        },
        "AES-SIV-CMAC" => Algorithm {
            file: "aes_siv_cmac_test.json",
            generator: aes_siv::generator,
        },
        "AES-CMAC" => Algorithm {
            file: "aes_cmac_test.json",
            generator: mac::generator,
        },
        "HKDF-SHA-1" => Algorithm {
            file: "hkdf_sha1_test.json",
            generator: hkdf::generator,
        },
        "HKDF-SHA-256" => Algorithm {
            file: "hkdf_sha256_test.json",
            generator: hkdf::generator,
        },
        "HKDF-SHA-384" => Algorithm {
            file: "hkdf_sha384_test.json",
            generator: hkdf::generator,
        },
        "HKDF-SHA-512" => Algorithm {
            file: "hkdf_sha512_test.json",
            generator: hkdf::generator,
        },
        "HMACSHA1" => Algorithm {
            file: "hmac_sha1_test.json",
            generator: mac::generator,
        },
        "HMACSHA224" => Algorithm {
            file: "hmac_sha224_test.json",
            generator: mac::generator,
        },
        "HMACSHA256" => Algorithm {
            file: "hmac_sha256_test.json",
            generator: mac::generator,
        },
        "HMACSHA384" => Algorithm {
            file: "hmac_sha384_test.json",
            generator: mac::generator,
        },
        "HMACSHA512" => Algorithm {
            file: "hmac_sha512_test.json",
            generator: mac::generator,
        },
        "EDDSA" => Algorithm {
            file: "eddsa_test.json",
            generator: ed25519::generator,
        },
        "secp224r1" => Algorithm {
            file: "ecdsa_secp224r1_sha224_test.json",
            generator: ecdsa::generator,
        },
        "secp256r1" => Algorithm {
            file: "ecdsa_secp256r1_sha256_test.json",
            generator: ecdsa::generator,
        },
        "secp256k1" => Algorithm {
            file: "ecdsa_secp256k1_sha256_test.json",
            generator: ecdsa::generator,
        },
        "secp256k1-p1316" => Algorithm {
            file: "ecdsa_secp256k1_sha256_p1363_test.json",
            generator: ecdsa::generator,
        },
        "secp384r1" => Algorithm {
            file: "ecdsa_secp384r1_sha384_test.json",
            generator: ecdsa::generator,
        },
        "secp521r1" => Algorithm {
            file: "ecdsa_secp521r1_sha512_test.json",
            generator: ecdsa::generator,
        },
        _ => panic!("Unrecognized algorithm '{algorithm}'"),
    };

    let data = wycheproof::data(wycheproof_dir, algo.file);

    let infos = (algo.generator)(&data, algorithm, key_size);
    println!("Emitting {} test cases", infos.len());

    let mut txt_file = std::fs::File::create(descriptions_path).unwrap();
    for info in &infos {
        writeln!(&mut txt_file, "{}", info.desc).unwrap();
    }

    let mut out_file = std::fs::File::create(out_path).unwrap();
    let blobs: Vec<Vec<u8>> = infos.into_iter().flat_map(|info| info.data).collect();
    let (blb_data, _) = blobby::encode_blobs(&blobs);
    out_file.write_all(&blb_data).unwrap();
}
