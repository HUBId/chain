#![allow(non_snake_case)]

use uuid::{uuid, Uuid};

fn Ok() {}

const _: Uuid = uuid!("00000000-0000-0000-0000-000000000000");

fn main() {}
