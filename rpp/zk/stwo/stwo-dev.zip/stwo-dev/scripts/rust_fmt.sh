#!/bin/bash

cargo +nightly-2025-07-14 fmt --all -- "$@"
