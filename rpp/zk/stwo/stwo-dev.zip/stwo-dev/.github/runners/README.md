# Build and push

```bash

docker build .github/runners -t actions-runner:latest

```
