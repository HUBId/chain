dev benchmark results can be seen at
https://starkware-libs.github.io/stwo/dev/bench/index.html
