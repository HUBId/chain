#![allow(unreachable_code)]

#[tracing::instrument]
const fn unit() {
    ""
}

fn main() {}
