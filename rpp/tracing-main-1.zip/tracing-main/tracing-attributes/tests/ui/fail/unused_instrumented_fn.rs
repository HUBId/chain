#![deny(dead_code)]

#[tracing::instrument]
fn never_used() {}

fn main() {}
