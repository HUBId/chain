# 0.1.0-beta.1 (November 29, 2024)

[ [crates.io][crate-0.1.0-beta.1] ] | [ [docs.rs][docs-0.1.0-beta.1] ]

`tracing-mock` provides tools for making assertions about what `tracing`
diagnostics are emitted by code under test.

- Initial beta release

[docs-0.1.0-beta.1]: https://docs.rs/tracing-mock/0.1.0-beta.1
[crate-0.1.0-beta.1]: https://crates.io/crates/tracing-mock/0.1.0-beta.1
