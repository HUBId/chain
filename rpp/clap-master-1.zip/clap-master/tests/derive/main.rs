#![cfg(feature = "derive")]
#![cfg(feature = "help")]
#![cfg(feature = "usage")]

automod::dir!("tests/derive");
