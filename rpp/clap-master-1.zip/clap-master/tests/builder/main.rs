#![allow(clippy::self_named_module_files)] // false positive
#![cfg(feature = "help")]
#![cfg(feature = "usage")]

automod::dir!("tests/builder");
