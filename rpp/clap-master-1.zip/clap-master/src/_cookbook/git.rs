//! # Example: git-like CLI (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/git.rs")]
//! ```
//!
#![doc = include_str!("../../examples/git.md")]
