//! # Example: git-like CLI (Derive API)
//!
//! ```rust
#![doc = include_str!("../../examples/git-derive.rs")]
//! ```
//!
#![doc = include_str!("../../examples/git-derive.md")]
