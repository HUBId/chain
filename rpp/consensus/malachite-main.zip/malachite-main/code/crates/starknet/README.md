> [!CAUTION]
> These crates will soon be extracted into their own repository at https://github.com/informalsystems/malachite-starknet.
