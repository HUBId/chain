#![allow(missing_docs)]

include!(concat!(env!("OUT_DIR"), "/test.rs"));
