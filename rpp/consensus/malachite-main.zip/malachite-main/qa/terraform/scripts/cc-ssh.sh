#!/bin/bash

chmod 400 "/root/.ssh/id_rsa"
