#!/bin/bash

while [ ! -f /etc/done ];
do
  sleep 5
done
