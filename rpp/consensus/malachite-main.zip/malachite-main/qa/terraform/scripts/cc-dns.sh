#!/bin/bash

systemctl reload-or-restart dnsmasq
