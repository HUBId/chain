# Gossip Communication Protocol

TODO: add some minimal documentation regarding `gossipsub`.
