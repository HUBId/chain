# Malachite Testing Notes

This directory collects notes on testing and experimenting with Malachite.
Please see [QA](../../qa) for more comprehensive testing.

- [Testing Malachite locally with Docker](./local.md)
