#[derive(Copy, Clone, Default)]
pub(crate) struct Style {
    pub(crate) multiline_array: bool,
}
