# How to run

```
$ # install cargo fuzz (if you don't have it)
$ cargo install cargo-fuzz
$ # run fuzzer
$ cargo +nightly fuzz run parse_document --fuzz-dir=.
```
