# Security Policy

## Supported Versions

By default we provide security patches for the latest released version only. On request we patch older versions.

## Reporting a Vulnerability

Please do not file a public issue on GitHub. Instead, please [file a private security vulnerability report](https://github.com/libp2p/rust-libp2p/security/advisories/new).
