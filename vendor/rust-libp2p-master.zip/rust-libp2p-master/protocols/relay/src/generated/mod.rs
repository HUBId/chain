// Automatically generated mod.rs
pub mod message_v2;
