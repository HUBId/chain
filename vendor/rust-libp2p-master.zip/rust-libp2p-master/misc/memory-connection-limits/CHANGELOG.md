## 0.5.0

<!-- Update to libp2p-swarm v0.47.0 -->

## 0.4.0

- Deprecate `void` crate.
  See [PR 5676](https://github.com/libp2p/rust-libp2p/pull/5676).

<!-- Update to libp2p-core v0.43.0 -->

## 0.3.0

<!-- Update to libp2p-swarm v0.45.0 -->

## 0.2.0


## 0.1.0

- Initial release.
