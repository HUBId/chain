## 0.3.1

- Reduce allocations during encoding.
  See [PR 4782](https://github.com/libp2p/rust-libp2p/pull/4782).

## 0.3.0

- Update to `asynchronous-codec` `v0.7.0`.
  See [PR 4636](https://github.com/libp2p/rust-libp2p/pull/4636).

## 0.2.0 

- Raise MSRV to 1.65.
  See [PR 3715].

[PR 3715]: https://github.com/libp2p/rust-libp2p/pull/3715

## 0.1.0

- Migrate from `prost` to `quick-protobuf`. This removes `protoc` dependency. See [PR 3312].

[PR 3312]: https://github.com/libp2p/rust-libp2p/pull/3312
