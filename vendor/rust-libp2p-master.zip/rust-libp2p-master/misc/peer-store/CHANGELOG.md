## 0.1.0

- Introduce `libp2p-peer-store`.
  See [PR 5724](https://github.com/libp2p/rust-libp2p/pull/5724).
