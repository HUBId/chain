## 0.4.0

<!-- Update to libp2p-core v0.43.0 -->

## 0.3.0

<!-- Update to libp2p-swarm v0.45.0 -->

## 0.2.1

- Fix end of stream handling when buffer is empty or not present.
  See [PR 5439](https://github.com/libp2p/rust-libp2p/pull/5439).

## 0.2.0

- Update to latest version of `libp2p-noise`.
  See [PR 4968](https://github.com/libp2p/rust-libp2p/pull/4968).

## 0.1.0

- Initial release.
  See [PR 4248].

[PR 4248]: https://github.com/libp2p/rust-libp2p/pull/4248
