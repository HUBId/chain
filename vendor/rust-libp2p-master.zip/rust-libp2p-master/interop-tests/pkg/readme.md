# Wasm package directory

Content of this directory should be generated with
```
wasm pack build --target web
```
