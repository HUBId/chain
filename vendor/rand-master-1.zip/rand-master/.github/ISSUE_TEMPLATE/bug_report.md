---
name: Bug report
about: Something doesn't work as expected
title: ''
labels: X-bug
assignees: ''

---

## Summary

A clear and concise description of what the bug is.

What behaviour is expected, and why?

## Code sample

```rust
// Code demonstrating the problem
```
