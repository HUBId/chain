See <https://github.com/async-graphql/examples>.
