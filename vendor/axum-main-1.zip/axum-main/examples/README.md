# Examples

This folder contains numerous examples showing how to use axum. Each example is
setup as its own crate so its dependencies are clear.

For a list of what the community built with axum, please see the list
[here](../ECOSYSTEM.md).
